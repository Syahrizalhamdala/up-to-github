def contoh_fungsi():
    print("Fungsi ini akan diisi sesuai kebutuhan modul.")
